# Responsive Mail Inbox and Compose

A Pen created on CodePen.io. Original URL: [https://codepen.io/danielyewright/pen/EgYVxw](https://codepen.io/danielyewright/pen/EgYVxw).

